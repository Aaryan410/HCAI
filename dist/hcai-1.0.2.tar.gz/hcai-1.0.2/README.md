# HCAI
- A lightweight AI command-line interface powered by Hack Club AI.

- HCAI allows you to chat with multiple AI models directly from your terminal with streaming responses, persistent conversation history, and seamless model switching.

## Story...
- Well I wanted to use Claude and Codex together on same terminal but I don't know how to do it.
- I found out OpenCode, installed it and tried to configure but HC blocks OpenCode.
- So I though why not instead I build a dev tool and then HCAI was built.

## Update
- I updated the full README.
- Well before I hardcoded the models available on Hack Club's AI website (stupid me). So now this code directly pull all the meta data of all the models via Hack Club's AI API keys.
- Made a solid interactive terminal based frontend.
- I got inspired from OpenCode and decided to make a frontend almost similar an AI chatbot.

## What it does?
- Basically you can switch between multiple AI Models so that you can use more than 1 AI models inside your terminal with JUST ONE COMMAND
- So for example if you want to use Claude and Codex for Backend, Claude for Frontend, Codex for Bug Solving and Gemini for simple Q/A you can absolutely do that by switching between this 3 models bu just one command.
- Well setup is also super simple, just past your Hack Club's AI API keys to it.
- No hassle with configuration or any other stuff, just directly it starts and by simple commands you can switch between models.

## Commands
- This are commands:

| Command | Description                |
|---------|----------------------------|
| /help   | Show available commands    |
| /use    | Switch AI model            |
| /config | Show current configuration |
| /clear  | Clear current conversation |
| /exit   | Exit HCAI                  |

- Well also you can use "/use <query>", so instead of query you write the name of AI Model for example you write Claude it will list all the Claude Models that Hack Club provides with their AI API keys.

## Installation 
- Basically just use "pip install hcai" on your terminal since I published this on PyPi org.
- You will get to setup it by just pasting you Hack Club's AI API key.

## Run it locally?

### Clone the repo
- Just run "git clone https://github.com/Aaryan410/HCAI.git"

### Install dependencies
- pip install -r requirements.txt

### Run HCAI
- Run it via "py -m hcai.main" or "python -m hcai.main"


